#include "Mebel.h"

const char * Mebel::name = "Mebel";