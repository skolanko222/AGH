#include "Lozko.h"

const char * Lozko::name = "Lozko";