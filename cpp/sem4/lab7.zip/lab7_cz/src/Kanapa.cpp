#include "Kanapa.h"

const char * Kanapa::name = "Kanapa";