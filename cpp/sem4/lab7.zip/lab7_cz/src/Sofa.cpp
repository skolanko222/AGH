#include "Sofa.h"

const char * Sofa::name = "Sofa";