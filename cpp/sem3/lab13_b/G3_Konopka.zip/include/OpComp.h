#pragma once

#include "Operation.h"
#include <iostream>
#include <string>
#include <cmath>

class OpComp : public Operation
{
   public:


};