#include <iostream>
#include "Wymierne.h"

using namespace std;

void Wymierne::print()
{
        cout << _licznik << "/" << _mianownik;

}
