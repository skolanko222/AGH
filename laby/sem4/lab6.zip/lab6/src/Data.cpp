#include "Data.h"
#include "List.h"

void IntData::addToList(List * list) {list->insert(this->_x);}// polimorficzne wywołanie i niejawna konwersja
void StringData::addToList(List * list) {list->insert(this->_str);}