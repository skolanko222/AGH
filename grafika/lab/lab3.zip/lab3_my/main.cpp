#include <wx/wxprec.h>
#include "gui.hpp"

class MyApp : public wxApp
{
public:
	virtual bool OnInit();
};



bool MyApp::OnInit()
{
	
	gui* fr = new gui();
	fr->Show(true);
	return true;
}
wxIMPLEMENT_APP(MyApp);